/* Amplify Params - DO NOT EDIT
	ENV
	REGION
	CLIENT_ID
	CLIENT_SECRET
Amplify Params - DO NOT EDIT */

var querystring = require('querystring');
const express = require('express');
const axios = require('axios'); // Use Axios library
const bodyParser = require('body-parser');
const awsServerlessExpressMiddleware = require('aws-serverless-express/middleware');

const CLIENT_ID = process.env.CLIENT_ID;
const CLIENT_SECRET = process.env.CLIENT_SECRET;
const REDIRECT_URI = process.env.REDIRECT_URI;

// Declare a new express app
const app = express();
app.use(bodyParser.json());
app.use(awsServerlessExpressMiddleware.eventContext());

// Enable CORS for all methods
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "*");
  next();
});

var stateKey = 'spotify_auth_state';
var generateRandomString = function(length) {
  var text = '';
  var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

  for (var i = 0; i < length; i++) {
    text += possible.charAt(Math.floor(Math.random() * possible.length));
  }
  return text;
};

app.get('/login', function(req, res) {
  var state = generateRandomString(16);
  res.cookie(stateKey, state);
  console.log("Starting backend login");
  // Your application requests authorization
  var scope = 'user-read-private user-read-email user-library-read user-top-read user-modify-playback-state user-read-playback-state playlist-modify-private playlist-modify-public';
  res.redirect('https://accounts.spotify.com/authorize?' +
    querystring.stringify({
      response_type: 'code',
      client_id: CLIENT_ID,
      scope: scope,
      redirect_uri: REDIRECT_URI,
      state: state
    }));
 });

app.get('/callback', async function(req, res) {
  // Your application requests refresh and access tokens
  // after checking the state parameter
  const code = req.query.code || null;
  const state = req.query.state || null;
  const storedState = req.cookies ? req.cookies[stateKey] : null;

  if (state === null || state !== storedState) {
    res.redirect('/#' + querystring.stringify({ error: 'state_mismatch' }));
  } else {
    res.clearCookie(stateKey);
    const authOptions = {
      url: 'https://accounts.spotify.com/api/token',
      method: 'post', // Change method to 'post'
      data: querystring.stringify({
        code: code,
        redirect_uri: REDIRECT_URI,
        grant_type: 'authorization_code',
      }),
      headers: {
        'Authorization': 'Basic ' + (new Buffer(CLIENT_ID + ':' + CLIENT_SECRET).toString('base64')),
        'Content-Type': 'application/x-www-form-urlencoded', // Set content type
      },
    };

    try {
      const response = await axios(authOptions);
      if (response.status === 200) {
        const access_token = response.data.access_token;
        const refresh_token = response.data.refresh_token;

        const options = {
          url: 'https://api.spotify.com/v1/me',
          method: 'get', // Change method to 'get'
          headers: { 'Authorization': 'Bearer ' + access_token },
        };

        // Use the access token to access the Spotify Web API
        const spotifyResponse = await axios(options);
        console.log(spotifyResponse.data);

        // We can also pass the token to the browser to make requests from there
        const absoluteURL = 'http://localhost:3000/search?' +
          querystring.stringify({ access_token: access_token }) + '&' +
          querystring.stringify({ refresh_token: refresh_token });

        res.redirect(absoluteURL);
      } else {
        res.redirect('http://localhost:3000/#' +
          querystring.stringify({ error: 'invalid_token' }));
      }
    } catch (error) {
      console.error(error);
      res.status(500).send('Internal Server Error'); // Handle errors properly
    }
  }
});

app.get('/refresh_token', async function(req, res) {
  // Requesting access token from refresh token
  const refresh_token = req.query.refresh_token;
  const authOptions = {
    url: 'https://accounts.spotify.com/api/token',
    method: 'post', // Change method to 'post'
    data: querystring.stringify({
      grant_type: 'refresh_token',
      refresh_token: refresh_token,
    }),
    headers: {
      'Authorization': 'Basic ' + (new Buffer(CLIENT_ID + ':' + CLIENT_SECRET).toString('base64')),
      'Content-Type': 'application/x-www-form-urlencoded', // Set content type
    },
  };

  console.log("About to send refresh request");

  try {
    const response = await axios(authOptions);
    if (response.status === 200) {
      const access_token = response.data.access_token;
      console.log("Refresh successful, about to send token");
      res.send({ 'access_token': access_token });
    } else {
      console.error("ERROR REFRESHING TOKEN");
      console.error(response.status);
      res.status(500).send('Internal Server Error'); // Handle errors properly
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error'); // Handle errors properly
  }
});

app.listen(8888, function() {
    console.log("App started");
});

// Export the app object. When executing the application locally, this does nothing. However,
// to port it to AWS Lambda, we will create a wrapper around that will load the app from
// this file
// ...
module.exports = app;
